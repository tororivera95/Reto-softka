package reto_sofka;

import Clases.Participante;
import Jframe.Principal;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 * Clase Inicio.
 *
 * @author Guillermo Toro
 * @version 1.0 - 01/10/2021
 */
public class Reto_Sofka {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {        
        new Principal();
    }
}
