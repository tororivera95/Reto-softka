package Jframe;

import Clases.Juego;
import Clases.Preguntas;
import Conexion.ConexionBD;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.sql.Statement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import javax.swing.*;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 * Clase Jugar.
 *
 * @author Guillermo Toro
 * @version 1.0 - 01/10/2021
 */
public class Jugar extends javax.swing.JFrame {

    private static ConexionBD con;
    private int respCorrecta;
    private String nomResCorrecta;
    private String[] respuestas = new String[4];
    private Juego miJuego;
    private Timer timer;

    /**
     * Creates new form Jugar
     */
    public Jugar(Juego miJuego) {
        ConexionBD conexion = new ConexionBD();
        initComponents();
        String sql = "", pregunta = "", nomCategoria = "";
        this.timer = new Timer();

        int categoria = 0;
        this.miJuego = miJuego;
        if (this.miJuego.isAyudaAmigo() == false) {
            this.btnAmigo.setEnabled(false);
        }
        if (this.miJuego.isAyudaCincuenta() == false) {
            this.btnCincuenta.setEnabled(false);
        }
        if (this.miJuego.isAyudaPublico() == false) {
            this.btnAyudaPublico.setEnabled(false);
        }
        Random ran = new Random();
        int num = ran.nextInt(5) + 1;

        try {
            Statement st = conexion.getCon().createStatement();
            sql = "SELECT pregunta, respuesta, valido, idCategoria FROM preguntas INNER JOIN respuestas ON preguntas.id = respuestas.idPreguntas "
                    + "WHERE preguntas.idDificultad = '" + miJuego.getCont() + "' AND preguntas.idCategoria = '" + num + "' AND respuestas.idPreguntas = preguntas.id;";
            ResultSet rs = st.executeQuery(sql);
            int i = 0;
            while (rs.next()) {
                String a = rs.getString(2);
                respuestas[i] = rs.getString(2);
                pregunta = rs.getString(1);
                categoria = Integer.parseInt(rs.getString(4));
                i += 1;
                if (rs.getString(3).equals("S")) {
                    respCorrecta = i;
                    nomResCorrecta = rs.getString(2);
                }
            }
            rs.close();
            sql = "SELECT nombre FROM `categoria` WHERE id = '" + categoria + "'";
            ResultSet rsCategoria = st.executeQuery(sql);
            if (rsCategoria.next()) {
                nomCategoria = rsCategoria.getString(1);
            }
            rsCategoria.close();
        } catch (SQLException e) {
            System.out.println("Error de conexion " + e);
        }

        System.out.println("Correcta " + respCorrecta); //Respuestas correctas
        JOptionPane.showMessageDialog(null, "Pregunta Nº " + this.miJuego.getCont(), "welcome message", JOptionPane.INFORMATION_MESSAGE);
        this.lblNumPregunta.setText("Pregunta Nº" + this.miJuego.getCont());
        this.lblCategoria.setText("Categoria: " + nomCategoria);
        this.lblPreguntas.setText(pregunta);
        this.lblOpcA.setText(String.valueOf(respuestas[0]));
        this.lblOpcB.setText(String.valueOf(respuestas[1]));
        this.lblOpcC.setText(String.valueOf(respuestas[2]));
        this.lblOpcD.setText(String.valueOf(respuestas[3]));

        this.timer.scheduleAtFixedRate(new TimerTask() {//Inicializamos el temporizador
            int i = 30; //Tiempo del temporizador

            public void run() {
                lblTemporizador.setText("Tiempo: " + i);
                i--;
                if (i < 10) {
                    lblTemporizador.setBackground(Color.RED);
                    lblTemporizador.setForeground(Color.red);
                    if (i < 0) {
                        timer.cancel();
                        //tiempoAgotado();
                    }
                }
            }
        }, 0, 1000);

        setVisible(true);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        buttonGroup4 = new javax.swing.ButtonGroup();
        buttonGroup5 = new javax.swing.ButtonGroup();
        lblTipoPregunta = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        lblCategoria = new javax.swing.JLabel();
        lblNumPregunta = new javax.swing.JLabel();
        lblPreguntas = new javax.swing.JLabel();
        lblOpcA = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        lblOpcB = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lblOpcC = new javax.swing.JLabel();
        lblOpcD = new javax.swing.JLabel();
        lblRespuesta = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtRespuesta = new javax.swing.JTextField();
        btnContinuar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        lblTemporizador = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btnAyudaPublico = new javax.swing.JButton();
        btnCincuenta = new javax.swing.JButton();
        btnAmigo = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("C.");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTipoPregunta.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lblCategoria.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblCategoria.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lblNumPregunta.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lblPreguntas.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblPreguntas.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        lblPreguntas.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lblOpcA.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblOpcA.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("1.");

        lblOpcB.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblOpcB.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("3.");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("2.");

        lblOpcC.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblOpcC.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lblOpcD.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblOpcD.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lblRespuesta.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblRespuesta.setText("Digite la respuesta correcta en numeros.");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("4.");

        txtRespuesta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRespuestaActionPerformed(evt);
            }
        });
        txtRespuesta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtRespuestaKeyTyped(evt);
            }
        });

        btnContinuar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnContinuar.setText("Continuar");
        btnContinuar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnContinuarActionPerformed(evt);
            }
        });

        btnSalir.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        lblTemporizador.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblTemporizador.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(lblPreguntas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5))
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblOpcD, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblOpcB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblOpcA, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblOpcC, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addComponent(lblCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblTemporizador, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(103, 103, 103)
                .addComponent(lblNumPregunta, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblRespuesta)
                .addGap(236, 236, 236))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(195, 195, 195)
                        .addComponent(btnContinuar, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(115, 115, 115)
                        .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(333, 333, 333)
                        .addComponent(txtRespuesta, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(209, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblNumPregunta, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
                    .addComponent(lblCategoria, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblTemporizador, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblPreguntas, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addComponent(lblOpcA, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblOpcB, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(lblOpcC, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblOpcD, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18)
                .addComponent(lblRespuesta)
                .addGap(18, 18, 18)
                .addComponent(txtRespuesta, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnContinuar)
                    .addComponent(btnSalir))
                .addGap(26, 26, 26))
        );

        btnAyudaPublico.setFont(new java.awt.Font("Tahoma", 0, 3)); // NOI18N
        btnAyudaPublico.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/publico.png"))); // NOI18N
        btnAyudaPublico.setToolTipText("");
        btnAyudaPublico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAyudaPublicoActionPerformed(evt);
            }
        });

        btnCincuenta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/50-por-ciento.png"))); // NOI18N
        btnCincuenta.setToolTipText("");
        btnCincuenta.setMaximumSize(new java.awt.Dimension(81, 57));
        btnCincuenta.setMinimumSize(new java.awt.Dimension(81, 57));
        btnCincuenta.setPreferredSize(new java.awt.Dimension(81, 57));
        btnCincuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCincuentaActionPerformed(evt);
            }
        });

        btnAmigo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/LlamadaAmigo.png"))); // NOI18N
        btnAmigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAmigoActionPerformed(evt);
            }
        });

        jLabel6.setText("Ayuda del publico");

        jLabel7.setText("50/50");

        jLabel8.setText("Llamada ");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(0, 21, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(32, 32, 32))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(36, 36, 36))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnAyudaPublico, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnCincuenta, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnAmigo, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addContainerGap())))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(btnAyudaPublico)
                .addGap(41, 41, 41)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnCincuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(51, 51, 51)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnAmigo)
                .addContainerGap(87, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(277, 277, 277)
                .addComponent(lblTipoPregunta)
                .addContainerGap(593, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblTipoPregunta, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tiempoAgotado() {
        int num = 0;
        num = miJuego.getCont() - 1;

        String sql = "";
        Date date = new Date();
        int dia = date.getDate();
        int mes = date.getMonth() + 1;
        int ano = date.getYear() + 1900;
        JOptionPane.showMessageDialog(null, "Tiempo agotado!");
        try {
            ConexionBD conexion = new ConexionBD();
            Statement st = conexion.getCon().createStatement();
            sql = "INSERT INTO `juego` (`id`, `fecha`, `idJugador`, `idDificultad`, `idPremio`) "
                    + "VALUES (NULL, '" + ano + "-" + mes + "-" + dia + "', '" + miJuego.getDatosParticipante().get(0).getId() + "', '" + num + "', '" + num + "');";
            st.execute(sql);

            sql = "UPDATE `participantes` SET `gano` = 'NO' "
                    + "WHERE `participantes`.`id` = '" + miJuego.getDatosParticipante().get(0).getId() + "'; ";
            st.executeUpdate(sql);

            sql = "INSERT INTO `acumulado` (`id`, `id_jugador`, `id_premio`) "
                    + "VALUES (NULL, '" + miJuego.getDatosParticipante().get(0).getId() + "', '" + num + "');";
            st.execute(sql);
            st.close();
        } catch (SQLException e) {
            System.out.println("Error de conexion " + e);
        }
        dispose();
        this.miJuego.setActividad(false);
    }

    private void btnContinuarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnContinuarActionPerformed
        String sql = "";
        Date date = new Date();
        int dia = date.getDate();
        int mes = date.getMonth() + 1;
        int ano = date.getYear() + 1900;
        try {
            int num = Integer.parseInt(this.txtRespuesta.getText());
            if (num != 1 && num != 2 && num != 3 && num != 4) {
                JOptionPane.showMessageDialog(rootPane, "Error, debe ingresar un valor numerico (1-2-3-4)", "ERROR", JOptionPane.WARNING_MESSAGE);
            } else {
                int ventana = JOptionPane.showConfirmDialog(null, "¿Seguro que es la respuesta correcta?", "QUESTION", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (ventana == 0) {
                    if (txtRespuesta.getText().equals(String.valueOf(respCorrecta))) {
                        this.miJuego.setCont(this.miJuego.getCont() + 1);

                        
                        
                       

                        
                        
                        JOptionPane.showMessageDialog(null, "Correcto!");
                        this.timer.cancel();
                        dispose();
                        if (this.miJuego.getCont() == 6) {
                            JOptionPane.showMessageDialog(null, "Felicitaciones has llegado a final \ndel Juego tu acumulado es por $10.000.000");
                            try {
                                ConexionBD conexion = new ConexionBD();
                                Statement st = conexion.getCon().createStatement();
                                sql = "INSERT INTO `juego` (`id`, `fecha`, `idJugador`, `idDificultad`, `idPremio`) "
                                        + "VALUES (NULL, '" + ano + "-" + mes + "-" + dia + "', '" + miJuego.getDatosParticipante().get(0).getId() + "', '5', '5');";
                                st.execute(sql);

                                sql = "UPDATE `participantes` SET `gano` = 'SI' "
                                        + "WHERE `participantes`.`id` = '" + miJuego.getDatosParticipante().get(0).getId() + "'; ";
                                st.executeUpdate(sql);

                                sql = "INSERT INTO `acumulado` (`id`, `id_jugador`, `id_premio`) "
                                        + "VALUES (NULL, '" + miJuego.getDatosParticipante().get(0).getId() + "', '5');";
                                st.execute(sql);
                                st.close();
                                this.timer.cancel();
                            } catch (SQLException e) {
                                System.out.println("Error de conexion " + e);
                            }
                            dispose();
                        } else {
                            dispose();
                            new Jugar(miJuego);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Perdiste!");
                        try {
                            ConexionBD conexion = new ConexionBD();
                            Statement st = conexion.getCon().createStatement();
                            sql = "INSERT INTO `juego` (`id`, `fecha`, `idJugador`, `idDificultad`, `idPremio`) "
                                    + "VALUES (NULL, '" + ano + "-" + mes + "-" + dia + "', '" + miJuego.getDatosParticipante().get(0).getId() + "', '" + miJuego.getCont() + "', '" + miJuego.getCont() + "');";
                            st.execute(sql);

                            sql = "UPDATE `participantes` SET `gano` = 'NO' "
                                    + "WHERE `participantes`.`id` = '" + miJuego.getDatosParticipante().get(0).getId() + "'; ";
                            st.executeUpdate(sql);

                            sql = "INSERT INTO `acumulado` (`id`, `id_jugador`, `id_premio`) "
                                    + "VALUES (NULL, '" + miJuego.getDatosParticipante().get(0).getId() + "', '" + miJuego.getCont() + "');";
                            st.execute(sql);
                            st.close();
                            this.timer.cancel();
                        } catch (SQLException e) {
                            System.out.println("Error de conexion " + e);
                        }
                        dispose();
                        this.miJuego.setActividad(false);
                    }
                }
            }

        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(rootPane, "Error, debe ingresar un valor numerico (1-2-3-4)", "ERROR", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btnContinuarActionPerformed

    private void txtRespuestaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRespuestaActionPerformed

    }//GEN-LAST:event_txtRespuestaActionPerformed

    private void txtRespuestaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtRespuestaKeyTyped

        char validar = evt.getKeyChar();
        if (Character.isLetter(validar)) {
            getToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(rootPane, "ERROR, debe ingresar solo numeros", "ERROR", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_txtRespuestaKeyTyped

    private void btnAmigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAmigoActionPerformed

        int RespCorrecta = 0;

        if (String.valueOf(nomResCorrecta).equals(String.valueOf(this.lblOpcA.getText()))) {
            RespCorrecta = 1;
        }

        if (String.valueOf(nomResCorrecta).equals(String.valueOf(this.lblOpcB.getText()))) {
            RespCorrecta = 2;
        }

        if (String.valueOf(nomResCorrecta).equals(String.valueOf(this.lblOpcC.getText()))) {
            RespCorrecta = 3;
        }

        if (String.valueOf(nomResCorrecta).equals(String.valueOf(this.lblOpcD.getText()))) {
            RespCorrecta = 4;
        }

        JOptionPane.showMessageDialog(null, "Tu amigo responde \nPara mi la respuesta correcta seria: " + RespCorrecta);

        this.btnAmigo.setEnabled(false);
        this.miJuego.setAyudaAmigo(false);

    }//GEN-LAST:event_btnAmigoActionPerformed

    private void btnCincuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCincuentaActionPerformed
        int pos = 0;
        if (pos != 2) {
            if (!nomResCorrecta.equals(String.valueOf(this.lblOpcB.getText()))) {
                this.lblOpcB.setText("N/A");
                pos = pos + 1;
            }
        }
        if (pos != 2) {
            if (!nomResCorrecta.equals(String.valueOf(this.lblOpcD.getText()))) {
                this.lblOpcD.setText("N/A");
                pos = pos + 1;
            }
        }
        if (pos != 2) {
            if (!nomResCorrecta.equals(String.valueOf(this.lblOpcA.getText()))) {
                this.lblOpcA.setText("N/A");
                pos = pos + 1;
            }
        }
        if (pos != 2) {
            if (!nomResCorrecta.equals(String.valueOf(this.lblOpcC.getText()))) {
                this.lblOpcC.setText("N/A");
                pos = pos + 1;
            }
        }
        this.btnCincuenta.setEnabled(false);
        this.miJuego.setAyudaCincuenta(false);
    }//GEN-LAST:event_btnCincuentaActionPerformed

    private void btnAyudaPublicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAyudaPublicoActionPerformed
        int porcA = 0, porcB = 0, porcC = 0, porcD = 0;

        if (String.valueOf(nomResCorrecta).equals(String.valueOf(this.lblOpcA.getText()))) {
            porcA = 80;
        } else {
            porcA = 50;
        }
        if (String.valueOf(nomResCorrecta).equals(String.valueOf(this.lblOpcB.getText()))) {
            porcB = 80;
        } else {
            porcB = 60;
        }
        if (String.valueOf(nomResCorrecta).equals(String.valueOf(this.lblOpcC.getText()))) {
            porcC = 80;
        } else {
            porcC = 70;
        }

        if (String.valueOf(nomResCorrecta).equals(String.valueOf(this.lblOpcD.getText()))) {
            porcD = 80;
        } else {
            porcD = 10;
        }

        JOptionPane.showMessageDialog(null, "EL PUBLICO RESPONDIO\n1. "
                + porcA + "%\n2. "
                + porcB + "%\n3. "
                + porcC + "%\n4. "
                + porcD + "%");

        this.btnAyudaPublico.setEnabled(false);
        this.miJuego.setAyudaPublico(false);
    }//GEN-LAST:event_btnAyudaPublicoActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        ConexionBD conexion = new ConexionBD();
        Date date = new Date();
        int dia = date.getDate();
        int mes = date.getMonth() + 1;
        int ano = date.getYear() + 1900;
        String sql = "", total = "";

        try {
            Statement st = conexion.getCon().createStatement();
            sql = "SELECT valorPremio FROM `premios` WHERE id = '" + miJuego.getCont() + "';";
            ResultSet rs = st.executeQuery(sql);
            if (rs.next()) {
                total = rs.getString(1);
            }
        } catch (SQLException e) {
            System.out.println("Error de conexion " + e);
        }

        int ventana = JOptionPane.showConfirmDialog(null, "¿Seguro que desea finalizar el juego? \nTiene un acumulado de $" + total, "QUESTION", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);

        if (ventana == 0) {
            try {
                Statement st = conexion.getCon().createStatement();
                sql = "INSERT INTO `juego` (`id`, `fecha`, `idJugador`, `idDificultad`, `idPremio`) "
                        + "VALUES (NULL, '" + ano + "-" + mes + "-" + dia + "', '" + miJuego.getDatosParticipante().get(0).getId() + "', '" + miJuego.getCont() + "', '" + miJuego.getCont() + "');";
                st.execute(sql);

                sql = "UPDATE `participantes` SET `gano` = 'SI' "
                        + "WHERE `participantes`.`id` = '" + miJuego.getDatosParticipante().get(0).getId() + "'; ";
                st.executeUpdate(sql);

                sql = "INSERT INTO `acumulado` (`id`, `id_jugador`, `id_premio`) "
                        + "VALUES (NULL, '" + miJuego.getDatosParticipante().get(0).getId() + "', '" + miJuego.getCont() + "');";
                st.execute(sql);
                st.close();
            } catch (SQLException e) {
                System.out.println("Error de conexion " + e);
            }
            dispose();
        }
    }//GEN-LAST:event_btnSalirActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAmigo;
    private javax.swing.JButton btnAyudaPublico;
    private javax.swing.JButton btnCincuenta;
    private javax.swing.JButton btnContinuar;
    private javax.swing.JButton btnSalir;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.ButtonGroup buttonGroup4;
    private javax.swing.ButtonGroup buttonGroup5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblCategoria;
    private javax.swing.JLabel lblNumPregunta;
    private javax.swing.JLabel lblOpcA;
    private javax.swing.JLabel lblOpcB;
    private javax.swing.JLabel lblOpcC;
    private javax.swing.JLabel lblOpcD;
    private javax.swing.JLabel lblPreguntas;
    private javax.swing.JLabel lblRespuesta;
    private javax.swing.JLabel lblTemporizador;
    private javax.swing.JLabel lblTipoPregunta;
    private javax.swing.JTextField txtRespuesta;
    // End of variables declaration//GEN-END:variables
}
