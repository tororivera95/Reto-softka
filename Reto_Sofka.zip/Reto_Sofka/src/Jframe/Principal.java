package Jframe;

import Clases.Juego;
import Clases.Participante;
import Conexion.ConexionBD;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import java.util.Date;
import java.sql.ResultSet;

/**
 * Clase Principal.
 *
 * @author Guillermo Toro
 * @version 1.0 - 01/10/2021
 */
public class Principal extends javax.swing.JFrame {

    private Juego Mijuego;
    private ArrayList<Participante> datosParticipante;

    // Constructor
    public Principal() {
        this.Mijuego = new Juego(100, 1, 0);
        this.datosParticipante = new ArrayList();
        ingresar();
    }

    public void ingresar() {
        Date date = new Date();
        int dia = date.getDate();
        int mes = date.getMonth() + 1;
        int ano = date.getYear() + 1900;

        String id = "", sql = "";
        initComponents();
        while (true) {
            id = JOptionPane.showInputDialog("Por favor ingrese la ID del participante");
            if (id == null) {
                int ventana = JOptionPane.showConfirmDialog(null, "¿Desea Salir?", "QUESTION", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (ventana != 0) {
                    continue;
                } else {
                    dispose();
                    break;
                }
            } else {
                if (id == null || id.isEmpty() || !isNumber(id)) {
                    JOptionPane.showMessageDialog(null, "Datos ingresados erroneos, intente de nuevo");
                    continue;
                } else {
                    int idParticipante = Integer.parseInt(id);
                    Participante p = Mijuego.buscarParticipante(idParticipante);
                    datosParticipante.add(p);
                    if (p != null) {
                        Mijuego.setDatosParticipante(datosParticipante); //Validamos si el jugador existe en la base de datos
                        boolean validador = Mijuego.actividadParticipante(idParticipante);
                        if (validador == true) {
                            this.lblNombreParticipante.setText(p.getNombre() + " " + p.getApellido());
                            setVisible(true);
                            break;
                        } else {
                            JOptionPane.showMessageDialog(null, "El participante con id " + idParticipante + " ya participo");
                            break;
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Participante con id  " + id + " no existente");
                        int ventana = JOptionPane.showConfirmDialog(null, "¿Desea registrarse?", "QUESTION", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
                        if (ventana == 0) {
                            new CrearParticipante(Mijuego);
                            break;
                        } else {
                            JOptionPane.showMessageDialog(null, "Hasta Pronto");
                            dispose();
                            break;
                        }
                    }
                }
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnInstrucciones = new javax.swing.JButton();
        btnJugar = new javax.swing.JButton();
        btnRecord = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        lblNombreParticipante = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel1.setText("QUIEN QUIERE SER MILLONARIO");

        btnInstrucciones.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnInstrucciones.setText("Instrucciones");
        btnInstrucciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInstruccionesActionPerformed(evt);
            }
        });

        btnJugar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnJugar.setText("Jugar");
        btnJugar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnJugarActionPerformed(evt);
            }
        });

        btnRecord.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnRecord.setText("Record");
        btnRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRecordActionPerformed(evt);
            }
        });

        btnSalir.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Nombre Participante");

        lblNombreParticipante.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblNombreParticipante.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(130, 130, 130)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnInstrucciones)
                            .addComponent(btnJugar, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblNombreParticipante, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(43, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(31, 31, 31)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(lblNombreParticipante, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addComponent(btnJugar)
                .addGap(32, 32, 32)
                .addComponent(btnInstrucciones, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(btnRecord)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addComponent(btnSalir)
                .addGap(20, 20, 20))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnJugarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnJugarActionPerformed
        new Jugar(Mijuego);
        dispose();
    }//GEN-LAST:event_btnJugarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        int ventana = JOptionPane.showConfirmDialog(null, "¿Seguro que desea Salir?", "QUESTION", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (ventana == 0) {
            JOptionPane.showMessageDialog(null, "Hasta Pronto");
            dispose();
        }
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRecordActionPerformed
        ConexionBD conexion = new ConexionBD();
        String sql = "";
        ArrayList id = new ArrayList();
        ArrayList idPremio = new ArrayList();
        int cont = 0;
        try {
            Statement st = conexion.getCon().createStatement();
            sql = "SELECT id, idPremio FROM `juego`";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                id.add(rs.getString(1));
                idPremio.add(rs.getString(2));
                cont += 1;
            }
            rs.close();
        } catch (SQLException e) {
            System.out.println("Error de conexion " + e);
        }
        for (int i = 0; i < cont; i++) {
            JOptionPane.showMessageDialog(null, "ID " + id.get(i) + "\n" + "Dificultad obtenida " + idPremio.get(i));
        }
    }//GEN-LAST:event_btnRecordActionPerformed

    private void btnInstruccionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInstruccionesActionPerformed
        new Instrucciones();
    }//GEN-LAST:event_btnInstruccionesActionPerformed

    /**
     * Funcion que permite validar que solo se ingresen numeros
     *
     * @param n
     * @return
     */
    private static boolean isNumber(String dato) {
        try {
            Integer.parseInt(dato);
            return true;
        } catch (NumberFormatException nfe) {
            return false;
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnInstrucciones;
    private javax.swing.JButton btnJugar;
    private javax.swing.JButton btnRecord;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblNombreParticipante;
    // End of variables declaration//GEN-END:variables

}
