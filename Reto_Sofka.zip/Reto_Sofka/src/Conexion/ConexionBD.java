package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
/**
 *
 * @author TORO
 */
public class ConexionBD {

    private Connection con = null;
    private String user = "root";
    private String pass = "";
    private String url = "jdbc:mysql://localhost:3306/retosoftka";
    private String driver = "com.mysql.jdbc.Driver";

    /**
     * Funcion que permite la conexion a la base de datos
     */
    public ConexionBD() {
        con = null;
        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url, user, pass);
            if (con != null) {
                System.out.println("Conexion satisfactoria");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Conexion fallida : " + e);
        }
    }

    /**
     * Funcion que permite llamar la conexion getCon
     *
     * @return
     */
    public Connection getCon() {
        return con;
    }

    /**
     * Funcion que permite cerrar la conexion a la base de datos
     */
    public void cerrar() {
        if (con != null) {
            try {
                con.close();
                con = null;
            } catch (SQLException e) {
                System.out.println("ERROR " + e);
            }
        }
    }
}
