package Clases;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import Conexion.ConexionBD;
import java.sql.Statement;
import java.sql.SQLException;
import java.sql.ResultSet;

/**
 * Clase Juego.
 *
 * @author Guillermo Toro
 * @version 1.0 - 01/10/2021
 */
public class Juego {

    private static ConexionBD con;
    private int numeroJuego;
    private int cont;
    private int puntos;
    private boolean actividad;
    private boolean ayudaCincuenta;
    private boolean ayudaAmigo;
    private boolean ayudaPublico;
    private ArrayList<Participante> datosParticipante;
    private ArrayList<Preguntas> listaPreguntas;

    //Constructores
    public Juego(int numeroJuego, int cont, int puntos) {
        this.numeroJuego = numeroJuego;
        this.cont = cont;
        this.puntos = puntos;
        this.actividad = true;
        this.ayudaAmigo = true;
        this.ayudaCincuenta = true;
        this.ayudaPublico = true;
        this.datosParticipante = new ArrayList();
        this.listaPreguntas = new ArrayList();
    }

    public Juego() {
        this.numeroJuego = 0;
        this.cont = 0;
        this.puntos = 0;
        this.actividad = true;
        this.ayudaAmigo = true;
        this.ayudaCincuenta = true;
        this.ayudaPublico = true;
        this.datosParticipante = new ArrayList();
        this.listaPreguntas = new ArrayList();
    }

    //Get and Set
    public int getNumeroJuego() {
        return numeroJuego;
    }

    public void setNumeroJuego(int numeroJuego) {
        this.numeroJuego = numeroJuego;
    }

    public int getCont() {
        return cont;
    }

    public void setCont(int cont) {
        this.cont = cont;
    }

    public ArrayList<Participante> getDatosParticipante() {
        return datosParticipante;
    }

    public void setDatosParticipante(ArrayList<Participante> datosParticipante) {
        this.datosParticipante = datosParticipante;
    }

    public ArrayList<Preguntas> getListaPreguntas() {
        return listaPreguntas;
    }

    public void setListaPreguntas(ArrayList<Preguntas> listaPreguntas) {
        this.listaPreguntas = listaPreguntas;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public boolean isActividad() {
        return actividad;
    }

    public void setActividad(boolean actividad) {
        this.actividad = actividad;
    }

    public boolean isAyudaCincuenta() {
        return ayudaCincuenta;
    }

    public void setAyudaCincuenta(boolean ayudaCincuenta) {
        this.ayudaCincuenta = ayudaCincuenta;
    }

    public boolean isAyudaAmigo() {
        return ayudaAmigo;
    }

    public void setAyudaAmigo(boolean ayudaAmigo) {
        this.ayudaAmigo = ayudaAmigo;
    }

    public boolean isAyudaPublico() {
        return ayudaPublico;
    }

    public void setAyudaPublico(boolean ayudaPublico) {
        this.ayudaPublico = ayudaPublico;
    }

    //Metodos
    /**
     * Funcion que permite crear un Participante.
     */
    public boolean crearParticipante(int id, String nombre, String apellido, int edad) {
        boolean validador = false;
        Participante p = new Participante();
        String sql = "";
        ConexionBD conexion = new ConexionBD();
        p = buscarParticipante(id);
        if (p == null) {
            try {
                Statement st = conexion.getCon().createStatement();
                sql = "INSERT INTO `participantes` (`id`, `nombre`, `apellido`, `edad`, `gano`) "
                        + "VALUES ('" + id + "', '" + nombre + "', '" + apellido + "', '" + edad + "', 'NA');";
                st.execute(sql); //Se guardan el nuevo participante en la base de datos
                JOptionPane.showMessageDialog(null, "Participante creado con Exito", "PROCESO EXITOSO", JOptionPane.INFORMATION_MESSAGE);
                validador = true;
            } catch (SQLException e) {
                System.out.println("Error de conexion " + e);
            }
        } else {
            JOptionPane.showMessageDialog(null, "ID del participante ya existente");
        }
        return validador;
    }

    /**
     * Funcion que permite buscar un participante
     *
     * @param id
     * @return
     */
    public Participante buscarParticipante(int id) {
        ConexionBD conexion = new ConexionBD();
        String sql = "", validador = "", nombre = "", apellido = "", permiso = "";
        int edad = 0;
        Participante p = new Participante();
        try {
            Statement st = conexion.getCon().createStatement();
            sql = "SELECT * FROM `participantes` WHERE id = '" + id + "';";
            ResultSet rs = st.executeQuery(sql);
            if (rs.isBeforeFirst()) {
                while (rs.next()) {
                    nombre = rs.getString(2);
                    apellido = rs.getString(3);
                    edad = Integer.parseInt(rs.getString(4));
                    permiso = rs.getString(5);
                }
                p = new Participante(id, nombre, apellido, edad, permiso);
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Error de conexion " + e);
        }
        return p;
    }

    public boolean actividadParticipante(int id) {
        ConexionBD conexion = new ConexionBD();
        String sql = "";
        boolean validador = false;
        try {
            Statement st = conexion.getCon().createStatement();
            sql = "SELECT gano FROM `participantes` WHERE id = '" + id + "'";
            ResultSet rs = st.executeQuery(sql);
            if (rs.next()) {
                if (rs.getString(1).equals("NA")) {
                    return !validador;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error de conexion " + e);
        }
        return validador;
    }

}
