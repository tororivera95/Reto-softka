package Clases;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author TORO
 */
public class Preguntas {

    private int cont;

    //Metodos
    public ArrayList<Preguntas> preguntaUno(int cont) {
        this.cont = cont;
        ArrayList Preguntas = new ArrayList();
        Random ran = new Random();
        int num = ran.nextInt(5) + 1;
        Preguntas preguntaUno = new Preguntas();
        if (cont == 1) {
            switch (num) {
                case 1:
                    Preguntas.add("¿Color del sol?");
                    Preguntas.add("Amarillo");
                    Preguntas.add("Azul");
                    Preguntas.add("Rojo");
                    Preguntas.add("Vinotinto");
                    Preguntas.add("Amarillo");
                    Preguntas.add(num);
                    Preguntas.add("Colores Naturaleza");
                    break;
                case 2:
                    Preguntas.add("¿Color del cielo?");
                    Preguntas.add("Amarillo");
                    Preguntas.add("Azul");
                    Preguntas.add("Rojo");
                    Preguntas.add("Vinotinto");
                    Preguntas.add("Azul");
                    Preguntas.add(num);
                    Preguntas.add("Colores Naturaleza");
                    break;
                case 3:
                    Preguntas.add("¿Color de la nubes?");
                    Preguntas.add("Amarillo");
                    Preguntas.add("Azul");
                    Preguntas.add("Blanco");
                    Preguntas.add("Vinotinto");
                    Preguntas.add("Blanco");
                    Preguntas.add(num);
                    Preguntas.add("Colores Naturaleza");
                    break;
                case 4:
                    Preguntas.add("¿Color del pasto?");
                    Preguntas.add("Amarillo");
                    Preguntas.add("Azul");
                    Preguntas.add("Rojo");
                    Preguntas.add("Verde");
                    Preguntas.add("Verde");
                    Preguntas.add(num);
                    Preguntas.add("Colores Naturaleza");
                    break;
                case 5:
                    Preguntas.add("¿Color del mar?");
                    Preguntas.add("Amarillo");
                    Preguntas.add("Azul");
                    Preguntas.add("Rojo");
                    Preguntas.add("Azul Mar");
                    Preguntas.add("Azul Mar");
                    Preguntas.add(num);
                    Preguntas.add("Colores Naturaleza");
                    break;
                default:
                    System.out.println("Error");
            }
        }

        if (cont == 2) {
            switch (num) {
                case 1:
                    Preguntas.add("¿Quien fue presidente de Colombia en (1994 - 1998)?");
                    Preguntas.add("César Augusto Gaviria Trujillo");
                    Preguntas.add("Andrés Pastrana Arango ");
                    Preguntas.add("Álvaro Uribe Vélez");
                    Preguntas.add("Iván Duque Márquez");
                    Preguntas.add("Ernesto Samper Pizano");
                    Preguntas.add(num);
                    Preguntas.add("Cultura Colombiana");
                    break;
                case 2:
                    Preguntas.add("¿Cuantos departamentos tiene el territorio Colombiano?");
                    Preguntas.add("33");
                    Preguntas.add("32");
                    Preguntas.add("34");
                    Preguntas.add("25");
                    Preguntas.add("32");
                    Preguntas.add(num);
                    Preguntas.add("Cultura Colombiana");
                    break;
                case 3:
                    Preguntas.add("¿Cuantas estrofas tiene el Himno nacional Colombiano?");
                    Preguntas.add("22");
                    Preguntas.add("14");
                    Preguntas.add("11");
                    Preguntas.add("13");
                    Preguntas.add("11");
                    Preguntas.add(num);
                    Preguntas.add("Cultura Colombiana");
                    break;
                case 4:
                    Preguntas.add("¿Como se llamaba el Libertador de la republica Colombiana?");
                    Preguntas.add("Agustín de Iturbide.");
                    Preguntas.add("Simon Bolivar");
                    Preguntas.add("Cristobal Colon");
                    Preguntas.add("Antonio José de Sucre");
                    Preguntas.add("Simon Bolivar");
                    Preguntas.add(num);
                    Preguntas.add("Cultura Colombiana");
                    break;
                case 5:
                    Preguntas.add("¿Cuales son los paises vecinos de Colombia?");
                    Preguntas.add("Venezuela-Brasil-Ecuador-Peru-Panama");
                    Preguntas.add("Venezuela-Argentina-Ecuador-Peru-Panama");
                    Preguntas.add("Venezuela-Brasil-Ecuador-Peru-Panama-Oceano Pacifico");
                    Preguntas.add("Venezuela-Brasil-Ecuador-Oceano Pacifico-Panama");
                    Preguntas.add("Venezuela-Brasil-Ecuador-Peru-Panama");
                    Preguntas.add(num);
                    Preguntas.add("Cultura Colombiana");
                    break;
                default:
                    System.out.println("Error");
            }
        }
        return Preguntas;
    }
}
